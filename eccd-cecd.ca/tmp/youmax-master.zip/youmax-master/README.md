youmax
======

Complete Youtube channel on your website - customize anything you want - Jquery plugin 


New Features:
- you can customize width and height of the widget on your website.
- columns for the videos can be customized (Example: you can now have a 3-column layout for the videos displayed.)
- the widget itself is responsive; given a width (or %) for the widget, the inner contents will resize accordingly.
- video player can be opened in the widget itself or in a lightbox.
- a top featured video can be opened in the video player on load of the widget.
- subscribe on youtube opens in a new tab.
- parts of the plugin like header/tabs can be hidden as per requirement.

Basic features:
- displays your actual complete youtube channel on your website just like its shown on youtube.
- youmax plugin will display your channel uploads, playlists and a featured playlist that you may choose.
- users can browse through your playlists and uploads and watch videos they like.

Instructions:
http://www.codehandling.com/2013/03/youmax-20-complete-youtube-channel-on.html

Live Edit Demo:
http://bitconfig.com/youmax/bitconfig_youmax.html